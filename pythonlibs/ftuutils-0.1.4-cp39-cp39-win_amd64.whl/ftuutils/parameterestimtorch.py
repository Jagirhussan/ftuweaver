import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import torch
import importlib, sys
import numpy as np
from tqdm import tqdm

def importFTULogic(fname, modname):
    spec = importlib.util.spec_from_file_location(modname, fname)
    if spec is None:
        raise ImportError(f"Could not load spec for module '{modname}' at: {fname}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[modname] = module
    try:
        spec.loader.exec_module(module)
    except FileNotFoundError as e:
        raise ImportError(f"{e.strerror}: {fname}") from e
    return module    

mod = importFTULogic(r'D:\12Labours\GithubRepositories\FTUUtils\test.py','FTU')

#Get nominal solution
t,u = mod.full_model()
U = u.reshape((25,4,-1))[:,2,:].squeeze()
#This should be gotten from mod
ng = {0: np.array([ 0,  5, 10, 15, 20]), 
        1: np.array([ 1,  6, 11, 16, 21]), 
        2: np.array([ 2,  7, 12, 17, 22]), 
        3: np.array([ 3,  8, 13, 18, 23]), 
        4: np.array([ 4,  9, 14, 19, 24])
        }
UReduced = np.zeros((len(ng),U.shape[1]))
for n,v in ng.items():
    UReduced[n,:] = np.mean(U[v,:],axis=0)

UReduced = torch.from_numpy(UReduced)
    


class ReducedFTUDynamics(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.param = torch.nn.Parameter(torch.rand(mod.PARAMETER_COUNT))

    def forward(self):
        t,r = mod.reduced_model(self.param)
        return torch.from_numpy(r.reshape((5,4,-1))[:,2,:].squeeze()).requires_grad_(True)

def lossfn(traj):
    return torch.abs(traj-UReduced).sum()

numiters = 100

model = ReducedFTUDynamics()
model.train()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

pbar = tqdm(range(numiters))
for itr in pbar:
    optimizer.zero_grad()
    trag = model()
    loss = lossfn(trag)
    loss.backward()
    optimizer.step()
    pbar.set_description(f"Loss: {loss.item():.3f}")
    


# initialParam = (torch.rand(mod.PARAMETER_COUNT)-0.5)*10
# initialParam.requires_grad_(True)
# initialParam.retain_grad()



# #optim = torch.optim.Adam([initialParam], lr=0.001, weight_decay=1e-2)
# optim = torch.optim.AdamW([initialParam], lr=0.001, weight_decay=1e-2)

# niters = 1000
# for i in range(niters):
#     loss = lossfn(initialParam)
#     loss.backward()
#     optim.step()
#     optim.zero_grad()
#     print(f"loss ({i}): {loss.item()}")

