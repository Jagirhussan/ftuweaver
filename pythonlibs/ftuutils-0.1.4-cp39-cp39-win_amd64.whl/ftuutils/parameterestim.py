import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

import torch
import importlib, sys
import numpy as np
from scipy.optimize import minimize

def importFTULogic(fname, modname):
    spec = importlib.util.spec_from_file_location(modname, fname)
    if spec is None:
        raise ImportError(f"Could not load spec for module '{modname}' at: {fname}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[modname] = module
    try:
        spec.loader.exec_module(module)
    except FileNotFoundError as e:
        raise ImportError(f"{e.strerror}: {fname}") from e
    return module    

mod = importFTULogic(r'D:\12Labours\GithubRepositories\FTUUtils\test.py','FTU')

#Get nominal solution
t,u = mod.full_model()
U = u.reshape((25,4,-1))[:,2,:].squeeze()
#This should be gotten from mod
ng = {0: np.array([ 0,  5, 10, 15, 20]), 
        1: np.array([ 1,  6, 11, 16, 21]), 
        2: np.array([ 2,  7, 12, 17, 22]), 
        3: np.array([ 3,  8, 13, 18, 23]), 
        4: np.array([ 4,  9, 14, 19, 24])
        }
UReduced = np.zeros((len(ng),U.shape[1]))
for n,v in ng.items():
    UReduced[n,:] = np.mean(U[v,:],axis=0)

# UReduced = torch.from_numpy(UReduced)
    
# def lossfn(param):
#     try:
#         t,r = mod.reduced_model(param)
#         U = torch.from_numpy(r.reshape((5,4,-1))[:,2,:].squeeze())
#         #print(torch.abs(U - UReduced).sum())
#         return torch.abs(U - UReduced).sum() + torch.linalg.norm(param)
#     except:
#         return torch.inf

# initialParam = (torch.rand(mod.PARAMETER_COUNT)-0.5)*10
# initialParam.requires_grad_(True)
# initialParam.retain_grad()



# #optim = torch.optim.Adam([initialParam], lr=0.001, weight_decay=1e-2)
# optim = torch.optim.AdamW([initialParam], lr=0.001, weight_decay=1e-2)

# niters = 1000
# for i in range(niters):
#     loss = lossfn(initialParam)
#     loss.backward()
#     optim.step()
#     optim.zero_grad()
#     print(f"loss ({i}): {loss.item()}")


def lossfn(param):
    try:
        t,r = mod.reduced_model(param)
        U = r.reshape((5,4,-1))[:,2,:].squeeze()
        return np.fabs(U - UReduced).sum() + np.linalg.norm(param)
    except:
        return torch.inf

initialParam = (np.random.rand(mod.PARAMETER_COUNT)-0.5)*10    
res = minimize(lossfn,initialParam,method='BFGS',options={'disp':True})
